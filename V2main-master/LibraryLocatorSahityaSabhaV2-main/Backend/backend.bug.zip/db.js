require("dotenv").config();
const mysql = require("mysql2");

const db = mysql.createPool({
  host: process.env.DB_HOST || "localhost",
  user: process.env.DB_USER || "root",
  password: process.env.DB_PASS,
  database: process.env.DB_NAME || "mssindor_yiilibrary",

  waitForConnections: true,
  connectionLimit: Number(process.env.DB_POOL_LIMIT) || 10,
  queueLimit: 0,

  enableKeepAlive: true,
  keepAliveInitialDelay: 0
});

// Optional pool events for logging
db.on("connection", () => {
  console.log("[DB] New connection created");
});

db.on("acquire", () => {
  console.log("[DB] Connection acquired");
});

db.on("release", () => {
  console.log("[DB] Connection released");
});

db.on("enqueue", () => {
  console.log("[DB] Waiting for available connection");
});

// Simple startup test
async function testDbConnection() {
  try {
    const [rows] = await db.promise().query("SELECT 1 AS ok");
    if (!rows?.length || rows[0].ok !== 1) {
      throw new Error("Test query failed");
    }
    console.log("[DB] Pool connected successfully");
  } catch (err) {
    console.error("[DB] Pool connection failed:", err.message);
    throw err;
  }
}

// Graceful shutdown
async function closeDbPool() {
  try {
    await db.promise().end();
    console.log("[DB] Pool closed");
  } catch (err) {
    console.error("[DB] Error while closing pool:", err.message);
  }
}

module.exports = {
  db,
  testDbConnection,
  closeDbPool
};