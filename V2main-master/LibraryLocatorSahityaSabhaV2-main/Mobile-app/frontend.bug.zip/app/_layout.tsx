import { Stack } from "expo-router";

import { ThemeProvider } from "../context/ThemeContext";
import { AuthProvider } from "../context/AuthContext";

export default function RootLayout() {

  return (

    <ThemeProvider>

      <AuthProvider>

        <Stack
          screenOptions={{
            headerShown: false
          }}
        >

          {/* Entry route */}
          <Stack.Screen name="index" />

          {/* Auth flow */}
          <Stack.Screen name="login" />
          <Stack.Screen name="signup" />
          <Stack.Screen name="verify-email" />
          <Stack.Screen name="forgot-password" />
          <Stack.Screen name="reset-password" />

          {/* Account management */}
          <Stack.Screen name="change-password" />
          <Stack.Screen name="delete-account" />

          {/* Main app tabs */}
          <Stack.Screen name="(tabs)" />

        </Stack>

      </AuthProvider>

    </ThemeProvider>

  );

}