import * as SecureStore from "expo-secure-store";
import { jwtDecode } from "jwt-decode";
import { Platform } from "react-native";

import { API_BASE } from "../constants/api";

const TOKEN_KEY = "auth_token";

/**
 * Web fallback storage
 */
async function getToken() {
  if (Platform.OS === "web") {
    return localStorage.getItem(TOKEN_KEY);
  }
  return await SecureStore.getItemAsync(TOKEN_KEY);
}

async function removeToken() {
  if (Platform.OS === "web") {
    localStorage.removeItem(TOKEN_KEY);
    return;
  }
  await SecureStore.deleteItemAsync(TOKEN_KEY);
}

/**
 * Check token expiry
 */
function isTokenExpired(token: string): boolean {
  try {
    const decoded: any = jwtDecode(token);

    if (!decoded.exp) return false;

    return decoded.exp < Date.now() / 1000;
  } catch {
    return true;
  }
}

/**
 * API wrapper
 */
export async function apiFetch(endpoint: string, options: RequestInit = {}) {
  try {

    const token = await getToken();

    if (token && isTokenExpired(token)) {
      await removeToken();
      throw new Error("SESSION_EXPIRED");
    }

    const headers: HeadersInit = {
      "Content-Type": "application/json",
      ...(options.headers || {}),
    };

    if (token) {
      headers["Authorization"] = `Bearer ${token}`;
    }

    const url = `${API_BASE}${endpoint}`;

    console.log("FULL URL =", url);

    const response = await fetch(url, {
      ...options,
      headers,
    });

    console.log("STATUS =", response.status);

    let data = null;

    try {
      data = await response.json();
    } catch {}

    console.log("DATA =", data);

    if (response.status === 401) {
      await removeToken();
      throw new Error("UNAUTHORIZED");
    }

    return {
      ok: response.ok,
      status: response.status,
      data,
    };

  } catch (error: any) {

    console.log("API ERROR =", error.message);

    if (
      error.message === "SESSION_EXPIRED" ||
      error.message === "UNAUTHORIZED"
    ) {
      throw error;
    }

    throw new Error("NETWORK_ERROR");
  }
}