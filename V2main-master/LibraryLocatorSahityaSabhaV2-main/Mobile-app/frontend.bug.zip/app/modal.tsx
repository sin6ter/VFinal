import { Link } from "expo-router";
import { StyleSheet, View } from "react-native";
import { Text } from "react-native-paper";

export default function ModalScreen() {

  return (

    <View style={styles.container}>

      <Text style={styles.title}>
        Modal Screen
      </Text>

      <Link
        href="/(tabs)/home"
        dismissTo
        style={styles.link}
      >

        Back to Home

      </Link>

    </View>

  );

}

const styles = StyleSheet.create({

  container: {
    flex: 1,
    justifyContent: "center",
    alignItems: "center",
    backgroundColor: "#08121c"
  },

  title: {
    fontSize: 22,
    color: "white"
  },

  link: {
    marginTop: 20,
    color: "#4db6ac"
  }

});