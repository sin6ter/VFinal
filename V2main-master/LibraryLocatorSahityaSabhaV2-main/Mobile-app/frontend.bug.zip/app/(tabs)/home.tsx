import { useState, useEffect, useRef } from "react";

import {
  View,
  Text,
  TextInput,
  TouchableOpacity,
  StyleSheet,
  Animated,
  ActivityIndicator,
  ScrollView,
  KeyboardAvoidingView,
  Platform
} from "react-native";

import * as Clipboard from "expo-clipboard";
import { Ionicons } from "@expo/vector-icons";
import { useRouter } from "expo-router";
import AsyncStorage from "@react-native-async-storage/async-storage";

import { useThemeContext } from "../../context/ThemeContext";
import { useAuth } from "../../context/AuthContext";
import { Colors } from "../../constants/theme";
import { apiFetch } from "../../services/api";

const RECENT_KEY = "recent_searches";
const MAX_RECENT = 6;

type Book = {
  bookname: string;
  bookauthor: string;
  bookpublisher: string;
  bookshelf: string;
  subject: string;
};

export default function Home() {

  const [search, setSearch] = useState("");
  const [suggestions, setSuggestions] = useState<Book[]>([]);
  const [result, setResult] = useState<Book | null>(null);
  const [loading, setLoading] = useState(false);
  const [error, setError] = useState("");
  const [hasSearched, setHasSearched] = useState(false);
  const [recentSearches, setRecentSearches] = useState<string[]>([]);
  const [copied, setCopied] = useState(false);

  const fadeAnim = useRef(new Animated.Value(0)).current;
  const slideAnim = useRef(new Animated.Value(20)).current;

  const { mode, toggleTheme } = useThemeContext();
  const theme = Colors[mode];

  const { logout } = useAuth();
  const router = useRouter();

  /*
  Load recent searches
  */

  useEffect(() => {

    AsyncStorage.getItem(RECENT_KEY)
      .then(raw => {
        if (raw)
          setRecentSearches(JSON.parse(raw));
      })
      .catch(() => {});

  }, []);

  /*
  Debounce search
  */

  useEffect(() => {

    if (search.trim().length < 2) {

      setSuggestions([]);
      setError("");
      setHasSearched(false);

      return;

    }

    const timeout = setTimeout(
      () => fetchSuggestions(search),
      350
    );

    return () => clearTimeout(timeout);

  }, [search]);

  /*
  Save recent searches
  */

  const saveRecent = async (query: string) => {

    const trimmed = query.trim();

    if (!trimmed) return;

    const updated = [
      trimmed,
      ...recentSearches.filter(r => r !== trimmed)
    ].slice(0, MAX_RECENT);

    setRecentSearches(updated);

    await AsyncStorage.setItem(
      RECENT_KEY,
      JSON.stringify(updated)
    );

  };

  /*
  Clear recent searches
  */

  const clearRecent = async () => {

    setRecentSearches([]);

    await AsyncStorage.removeItem(RECENT_KEY);

  };

  /*
  Fetch suggestions
  */

  const fetchSuggestions = async (query: string) => {

    setLoading(true);
    setError("");
    setHasSearched(true);

    try {

      const res = await apiFetch(
        `/search?book=${encodeURIComponent(query)}`
      );

      if (!res.ok) {

        setSuggestions([]);
        setError(res.data?.message || "Search failed.");

        return;

      }

      const data = res.data;

      if (data.success && Array.isArray(data.data)) {

        setSuggestions(data.data.slice(0, 10));

        if (!data.data.length)
          setError(
            `No books found for "${query.trim()}".`
          );

      }

      else {

        setSuggestions([]);
        setError("Search failed.");

      }

    }

    catch (err: any) {

      if (
        err.message === "SESSION_EXPIRED" ||
        err.message === "UNAUTHORIZED"
      ) {

        await logout();
        router.replace("/login");
        return;

      }

      setError("Cannot connect to server.");

    }

    finally {

      setLoading(false);

    }

  };

  /*
  Select book
  */

  const selectBook = (book: Book) => {

    setResult(book);
    setSuggestions([]);
    setSearch(book.bookname);
    setError("");

    saveRecent(book.bookname);

    setCopied(false);

    fadeAnim.setValue(0);
    slideAnim.setValue(24);

    Animated.parallel([

      Animated.timing(fadeAnim, {
        toValue: 1,
        duration: 350,
        useNativeDriver: true
      }),

      Animated.timing(slideAnim, {
        toValue: 0,
        duration: 350,
        useNativeDriver: true
      })

    ]).start();

  };

  /*
  Clear search
  */

  const clearSearch = () => {

    setSearch("");
    setSuggestions([]);
    setResult(null);
    setError("");
    setHasSearched(false);
    setCopied(false);

  };

  /*
  Copy shelf location
  */

  const copyShelf = async () => {

    if (!result) return;

    await Clipboard.setStringAsync(
      result.bookshelf
    );

    setCopied(true);

    setTimeout(
      () => setCopied(false),
      2000
    );

  };

  const tintBg =
    mode === "dark"
      ? "rgba(77,182,172,0.12)"
      : "rgba(0,121,107,0.08)";

  /*
  UI
  */

  return (

    <KeyboardAvoidingView
      style={{ flex: 1 }}
      behavior={
        Platform.OS === "ios"
          ? "padding"
          : undefined
      }
    >

      <ScrollView
        style={{
          backgroundColor: theme.background
        }}
        contentContainerStyle={styles.container}
        keyboardShouldPersistTaps="handled"
      >

        {/* HEADER */}

        <View style={styles.header}>

          <View>

            <Text
              style={[
                styles.title,
                { color: theme.text }
              ]}
            >
              Library Locator
            </Text>

            <Text
              style={[
                styles.subtitle,
                { color: theme.icon }
              ]}
            >
              Sahitya Sabha
            </Text>

          </View>

          <TouchableOpacity
            onPress={toggleTheme}
            style={[
              styles.iconBtn,
              { backgroundColor: theme.card }
            ]}
          >

            <Ionicons
              name={
                mode === "dark"
                  ? "sunny"
                  : "moon"
              }
              size={20}
              color={theme.tint}
            />

          </TouchableOpacity>

        </View>

        {/* SEARCH BAR */}

        <View
          style={[
            styles.searchContainer,
            {
              backgroundColor: theme.card,
              borderColor: theme.border
            }
          ]}
        >

          <Ionicons
            name="search-outline"
            size={18}
            color={theme.icon}
            style={{ marginRight: 10 }}
          />

          <TextInput
            placeholder="Search by title or author..."
            placeholderTextColor={theme.icon}
            value={search}
            onChangeText={setSearch}
            style={[
              styles.searchInput,
              { color: theme.text }
            ]}
            returnKeyType="search"
            autoCorrect={false}
          />

          {loading && (
            <ActivityIndicator
              size="small"
              color={theme.tint}
              style={{ marginLeft: 8 }}
            />
          )}

          {search.length > 0 && !loading && (

            <TouchableOpacity
              onPress={clearSearch}
              style={{ marginLeft: 6 }}
            >

              <Ionicons
                name="close-circle"
                size={18}
                color={theme.icon}
              />

            </TouchableOpacity>

          )}

        </View>

      </ScrollView>

    </KeyboardAvoidingView>

  );

}

const styles = StyleSheet.create({

  container: {
    padding: 20,
    paddingTop: 16,
    minHeight: "100%"
  },

  header: {
    flexDirection: "row",
    justifyContent: "space-between",
    alignItems: "center",
    marginBottom: 24
  },

  title: {
    fontSize: 24,
    fontWeight: "700"
  },

  subtitle: {
    fontSize: 13,
    marginTop: 2
  },

  iconBtn: {
    width: 40,
    height: 40,
    borderRadius: 20,
    alignItems: "center",
    justifyContent: "center"
  },

  searchContainer: {
    flexDirection: "row",
    alignItems: "center",
    borderRadius: 14,
    paddingHorizontal: 14,
    paddingVertical: 12,
    borderWidth: 1
  },

  searchInput: {
    flex: 1,
    fontSize: 15
  }

});