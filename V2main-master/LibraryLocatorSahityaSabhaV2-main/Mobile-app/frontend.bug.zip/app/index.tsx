import { useEffect } from "react";
import {
  View,
  ActivityIndicator,
  StyleSheet,
  ImageBackground
} from "react-native";

import { useRouter } from "expo-router";
import { useAuth } from "../context/AuthContext";

export default function Index() {

  const { isLoggedIn, isLoading } = useAuth();
  const router = useRouter();

  useEffect(() => {

    if (isLoading) return;

    if (isLoggedIn) {

      router.replace("/(tabs)/home");

    } else {

      router.replace("/login");

    }

  }, [isLoading, isLoggedIn, router]);


  return (

    <ImageBackground
      source={require("../assets/images/books-bg.jpeg")}
      style={styles.background}
      resizeMode="cover"
    >

      <View style={styles.overlay} />

      <View style={styles.centered}>

        <ActivityIndicator
          size="large"
          color="#4db6ac"
        />

      </View>

    </ImageBackground>

  );

}


const styles = StyleSheet.create({

  background: {
    flex: 1
  },

  overlay: {
    ...StyleSheet.absoluteFillObject,
    backgroundColor: "rgba(0,0,0,0.55)"
  },

  centered: {
    flex: 1,
    justifyContent: "center",
    alignItems: "center"
  }

});