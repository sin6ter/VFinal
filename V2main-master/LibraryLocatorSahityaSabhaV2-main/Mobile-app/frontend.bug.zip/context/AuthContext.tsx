import React, {
  createContext,
  useContext,
  useState,
  useEffect
} from "react";

import * as SecureStore from "expo-secure-store";
import { jwtDecode } from "jwt-decode";
import { Platform } from "react-native";

const AUTH_STORAGE_KEY = "auth_token";

type DecodedToken = {
  exp: number;
  superuser?: number;
};

type AuthContextType = {
  token: string | null;
  isLoggedIn: boolean;
  isLoading: boolean;
  isSuperAdmin: boolean;
  login: (token: string) => Promise<void>;
  logout: () => Promise<void>;
};

const AuthContext =
  createContext<AuthContextType | null>(null);


/*
Cross-platform storage helpers
*/

const saveToken = async (token: string) => {
  if (Platform.OS === "web") {
    localStorage.setItem(AUTH_STORAGE_KEY, token);
  } else {
    await SecureStore.setItemAsync(
      AUTH_STORAGE_KEY,
      token
    );
  }
};

const getToken = async () => {
  if (Platform.OS === "web") {
    return localStorage.getItem(
      AUTH_STORAGE_KEY
    );
  }

  return await SecureStore.getItemAsync(
    AUTH_STORAGE_KEY
  );
};

const deleteToken = async () => {
  if (Platform.OS === "web") {
    localStorage.removeItem(
      AUTH_STORAGE_KEY
    );
  } else {
    await SecureStore.deleteItemAsync(
      AUTH_STORAGE_KEY
    );
  }
};


/*
Auth Provider
*/

export const AuthProvider = ({
  children
}: {
  children: React.ReactNode;
}) => {

  const [token, setToken] =
    useState<string | null>(null);

  const [isSuperAdmin, setIsSuperAdmin] =
    useState(false);

  const [isLoading, setIsLoading] =
    useState(true);


/*
Validate JWT expiration
*/

  const isTokenValid = (
    token: string
  ) => {

    try {

      const decoded =
        jwtDecode<DecodedToken>(token);

      if (!decoded.exp)
        return false;

      const now =
        Date.now() / 1000;

      return decoded.exp > now;

    } catch {

      return false;

    }

  };


/*
Restore session
*/

  useEffect(() => {

    const restoreSession =
      async () => {

        try {

          const savedToken =
            await getToken();

          if (
            savedToken &&
            isTokenValid(savedToken)
          ) {

            const decoded =
              jwtDecode<DecodedToken>(
                savedToken
              );

            setToken(savedToken);

            setIsSuperAdmin(
              decoded.superuser === 1
            );

          } else {

            await deleteToken();

            setToken(null);

            setIsSuperAdmin(false);

          }

        } catch {

          setToken(null);

          setIsSuperAdmin(false);

        } finally {

          setIsLoading(false);

        }

      };

    restoreSession();

  }, []);


/*
Login handler
*/

  const login = async (
    newToken: string
  ) => {

    await saveToken(newToken);

    const decoded =
      jwtDecode<DecodedToken>(
        newToken
      );

    setToken(newToken);

    setIsSuperAdmin(
      decoded.superuser === 1
    );

  };


/*
Logout handler
*/

  const logout = async () => {

    await deleteToken();

    setToken(null);

    setIsSuperAdmin(false);

  };


  return (

    <AuthContext.Provider
      value={{
        token,
        isLoggedIn:
          token !== null,
        isLoading,
        isSuperAdmin,
        login,
        logout
      }}
    >

      {children}

    </AuthContext.Provider>

  );

};


export const useAuth =
  (): AuthContextType => {

    const context =
      useContext(AuthContext);

    if (!context)
      throw new Error(
        "useAuth must be used inside AuthProvider"
      );

    return context;

};